-- Kaspa Mainnet Database Schema
-- Optimized for 10 BPS with batch inserts

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- Blocks table with optimized indexing
CREATE TABLE IF NOT EXISTS blocks (
    id BIGSERIAL PRIMARY KEY,
    hash VARCHAR(64) NOT NULL UNIQUE,
    accepted_id_merkle_root VARCHAR(64),
    difficulty NUMERIC(20,0),
    merge_set_blues_hashes TEXT[],
    merge_set_reds_hashes TEXT[],
    selected_parent_hash VARCHAR(64),
    bits BIGINT,
    blue_score BIGINT NOT NULL,
    blue_work VARCHAR(64),
    daa_score BIGINT NOT NULL,
    hash_merkle_root VARCHAR(64),
    nonce VARCHAR(64),
    pruning_point VARCHAR(64),
    timestamp BIGINT NOT NULL,
    utxo_commitment VARCHAR(64),
    version INT,
    parents TEXT[],
    is_chain_block BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Optimized indexes for 10 BPS queries
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_blocks_blue_score ON blocks (blue_score DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_blocks_daa_score ON blocks (daa_score DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_blocks_timestamp ON blocks (timestamp DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_blocks_hash ON blocks USING hash (hash);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_blocks_created_at ON blocks (created_at DESC);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
    id BIGSERIAL PRIMARY KEY,
    transaction_id VARCHAR(64) NOT NULL UNIQUE,
    block_hash VARCHAR(64) REFERENCES blocks(hash) ON DELETE CASCADE,
    block_time BIGINT,
    is_accepted BOOLEAN DEFAULT true,
    accepting_block_hash VARCHAR(64),
    subnetwork_id VARCHAR(64),
    lock_time BIGINT,
    gas BIGINT,
    payload_hash VARCHAR(64),
    payload TEXT,
    mass BIGINT,
    version INT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_transactions_block_hash ON transactions (block_hash);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_transactions_id ON transactions USING hash (transaction_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_transactions_block_time ON transactions (block_time DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_transactions_created_at ON transactions (created_at DESC);

-- Transaction inputs
CREATE TABLE IF NOT EXISTS transaction_inputs (
    id BIGSERIAL PRIMARY KEY,
    transaction_id VARCHAR(64) REFERENCES transactions(transaction_id) ON DELETE CASCADE,
    previous_outpoint_hash VARCHAR(64),
    previous_outpoint_index INT,
    signature_script TEXT,
    sig_op_count BIGINT,
    sequence BIGINT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tx_inputs_transaction_id ON transaction_inputs (transaction_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tx_inputs_prev_hash ON transaction_inputs (previous_outpoint_hash);

-- Transaction outputs
CREATE TABLE IF NOT EXISTS transaction_outputs (
    id BIGSERIAL PRIMARY KEY,
    transaction_id VARCHAR(64) REFERENCES transactions(transaction_id) ON DELETE CASCADE,
    output_index INT,
    amount BIGINT,
    script_public_key TEXT,
    script_public_key_address VARCHAR(255),
    script_public_key_type VARCHAR(50),
    is_spent BOOLEAN DEFAULT false,
    spent_by_transaction_id VARCHAR(64),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tx_outputs_transaction_id ON transaction_outputs (transaction_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tx_outputs_address ON transaction_outputs (script_public_key_address);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tx_outputs_spent ON transaction_outputs (is_spent);

-- Address balances (materialized view for performance)
CREATE TABLE IF NOT EXISTS address_balances (
    address VARCHAR(255) PRIMARY KEY,
    balance BIGINT DEFAULT 0,
    transaction_count INT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT NOW()
);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_address_balance ON address_balances (balance DESC);

-- Network statistics
CREATE TABLE IF NOT EXISTS network_stats (
    id SERIAL PRIMARY KEY,
    timestamp BIGINT NOT NULL,
    block_count BIGINT,
    transaction_count BIGINT,
    difficulty NUMERIC(20,0),
    hashrate NUMERIC(30,0),
    network_hashrate_per_second NUMERIC(30,0),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_network_stats_timestamp ON network_stats (timestamp DESC);

-- Indexing progress tracker
CREATE TABLE IF NOT EXISTS indexer_state (
    id INT PRIMARY KEY DEFAULT 1,
    last_indexed_block_hash VARCHAR(64),
    last_indexed_blue_score BIGINT,
    last_indexed_daa_score BIGINT,
    last_sync_time TIMESTAMP,
    is_syncing BOOLEAN DEFAULT false,
    sync_progress_percent NUMERIC(5,2),
    CONSTRAINT single_row CHECK (id = 1)
);

INSERT INTO indexer_state (id, last_indexed_blue_score, last_indexed_daa_score, is_syncing)
VALUES (1, 0, 0, false)
ON CONFLICT (id) DO NOTHING;

-- Performance monitoring table
CREATE TABLE IF NOT EXISTS performance_metrics (
    id BIGSERIAL PRIMARY KEY,
    metric_name VARCHAR(100),
    metric_value NUMERIC(20,2),
    timestamp TIMESTAMP DEFAULT NOW()
);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_perf_metrics_name_time ON performance_metrics (metric_name, timestamp DESC);

-- Optimized function for batch block insertion
CREATE OR REPLACE FUNCTION insert_block_batch(
    p_blocks JSON
) RETURNS VOID AS $$
BEGIN
    INSERT INTO blocks (
        hash, accepted_id_merkle_root, difficulty, merge_set_blues_hashes,
        merge_set_reds_hashes, selected_parent_hash, bits, blue_score,
        blue_work, daa_score, hash_merkle_root, nonce, pruning_point,
        timestamp, utxo_commitment, version, parents
    )
    SELECT 
        (value->>'hash')::VARCHAR(64),
        (value->>'accepted_id_merkle_root')::VARCHAR(64),
        (value->>'difficulty')::NUMERIC(20,0),
        ARRAY(SELECT json_array_elements_text(value->'merge_set_blues_hashes'))::TEXT[],
        ARRAY(SELECT json_array_elements_text(value->'merge_set_reds_hashes'))::TEXT[],
        (value->>'selected_parent_hash')::VARCHAR(64),
        (value->>'bits')::BIGINT,
        (value->>'blue_score')::BIGINT,
        (value->>'blue_work')::VARCHAR(64),
        (value->>'daa_score')::BIGINT,
        (value->>'hash_merkle_root')::VARCHAR(64),
        (value->>'nonce')::VARCHAR(64),
        (value->>'pruning_point')::VARCHAR(64),
        (value->>'timestamp')::BIGINT,
        (value->>'utxo_commitment')::VARCHAR(64),
        (value->>'version')::INT,
        ARRAY(SELECT json_array_elements_text(value->'parents'))::TEXT[]
    FROM json_array_elements(p_blocks)
    ON CONFLICT (hash) DO NOTHING;
END;
$$ LANGUAGE plpgsql;

-- Performance tuning
ALTER TABLE blocks SET (autovacuum_vacuum_scale_factor = 0.01);
ALTER TABLE transactions SET (autovacuum_vacuum_scale_factor = 0.01);
ALTER TABLE transaction_inputs SET (autovacuum_vacuum_scale_factor = 0.05);
ALTER TABLE transaction_outputs SET (autovacuum_vacuum_scale_factor = 0.05);

-- Grant permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO kaspa_admin;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO kaspa_admin;

-- Create maintenance user
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'kaspa_readonly') THEN
        CREATE ROLE kaspa_readonly LOGIN PASSWORD 'readonly2026';
    END IF;
END
$$;

GRANT CONNECT ON DATABASE kaspa_mainnet TO kaspa_readonly;
GRANT USAGE ON SCHEMA public TO kaspa_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO kaspa_readonly;

-- Completion message
DO $$
BEGIN
    RAISE NOTICE '✓ Kaspa database schema initialized successfully';
    RAISE NOTICE '✓ Optimized for 10 BPS throughput';
    RAISE NOTICE '✓ All indexes created';
END $$;
