import { Pool, PoolClient } from 'pg';
import { config } from './config';
import { logger } from './logger';

export class DatabaseService {
    private pool: Pool;
    private connected = false;

    constructor() {
        this.pool = new Pool({
            connectionString: config.databaseUrl,
            max: 20,
            idleTimeoutMillis: 30000,
            connectionTimeoutMillis: 5000,
        });

        this.pool.on('connect', () => {
            this.connected = true;
        });

        this.pool.on('error', (err) => {
            logger.error('Database pool error:', err);
            this.connected = false;
        });
    }

    async connect(): Promise<void> {
        try {
            const client = await this.pool.connect();
            client.release();
            logger.info('✓ Database connected');
            this.connected = true;
        } catch (error) {
            logger.error('Database connection failed:', error);
            throw error;
        }
    }

    async disconnect(): Promise<void> {
        await this.pool.end();
        this.connected = false;
    }

    isConnected(): boolean {
        return this.connected;
    }

    async query(text: string, params?: any[]): Promise<any> {
        const start = Date.now();
        try {
            const result = await this.pool.query(text, params);
            const duration = Date.now() - start;
            logger.debug(`Query executed in ${duration}ms: ${text}`);
            return result;
        } catch (error) {
            logger.error('Query error:', error);
            throw error;
        }
    }

    async getClient(): Promise<PoolClient> {
        return await this.pool.query();
    }

    // Optimized queries for 10 BPS
    async getLatestBlocks(limit: number = 50): Promise<any[]> {
        const result = await this.query(
            'SELECT * FROM blocks ORDER BY blue_score DESC LIMIT $1',
            [limit]
        );
        return result.rows;
    }

    async getBlockByHash(hash: string): Promise<any> {
        const result = await this.query(
            'SELECT * FROM blocks WHERE hash = $1',
            [hash]
        );
        return result.rows[0];
    }

    async getTransactionsByBlockHash(blockHash: string): Promise<any[]> {
        const result = await this.query(
            'SELECT * FROM transactions WHERE block_hash = $1',
            [blockHash]
        );
        return result.rows;
    }

    async getAddressBalance(address: string): Promise<any> {
        const result = await this.query(
            'SELECT * FROM address_balances WHERE address = $1',
            [address]
        );
        return result.rows[0];
    }

    async getNetworkStats(): Promise<any> {
        const result = await this.query(
            'SELECT * FROM network_stats ORDER BY timestamp DESC LIMIT 1'
        );
        return result.rows[0];
    }
}
