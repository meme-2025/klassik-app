import axios from 'axios';
import { config } from './config';
import { logger } from './logger';
import { DatabaseService } from './database';
import { RedisCache } from './cache';

export class KaspaService {
    private restClient: any;
    private db: DatabaseService;
    private cache: RedisCache;
    private isMonitoring = false;
    private monitoringInterval: NodeJS.Timeout | null = null;
    private lastProcessedBlueScore = 0;
    private connected = false;

    constructor(db: DatabaseService, cache: RedisCache) {
        this.db = db;
        this.cache = cache;
        this.restClient = axios.create({
            baseURL: config.restServerUrl,
            timeout: 30000,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }

    async initialize(): Promise<void> {
        try {
            // Test connection to kaspa-rest-server
            await this.getNetworkInfo();
            this.connected = true;
            logger.info('✓ Kaspa service initialized');
        } catch (error) {
            logger.error('Failed to initialize Kaspa service:', error);
            throw error;
        }
    }

    isConnected(): boolean {
        return this.connected;
    }

    async getNetworkInfo(): Promise<any> {
        const cacheKey = 'network:info';
        
        // Check cache first
        const cached = await this.cache.get(cacheKey);
        if (cached) return cached;

        const response = await this.restClient.get('/info');
        const data = response.data;

        // Cache for 10 seconds
        await this.cache.set(cacheKey, data, 10);
        return data;
    }

    async getBlockByHash(hash: string): Promise<any> {
        const cacheKey = `block:${hash}`;
        
        const cached = await this.cache.get(cacheKey);
        if (cached) return cached;

        // Try database first
        const dbBlock = await this.db.getBlockByHash(hash);
        if (dbBlock) {
            await this.cache.set(cacheKey, dbBlock, 3600); // Cache 1 hour
            return dbBlock;
        }

        // Fallback to REST server
        const response = await this.restClient.get(`/blocks/${hash}`);
        const data = response.data;
        
        await this.cache.set(cacheKey, data, 3600);
        return data;
    }

    async getLatestBlocks(limit: number = 50): Promise<any[]> {
        const cacheKey = `blocks:latest:${limit}`;
        
        const cached = await this.cache.get(cacheKey);
        if (cached) return cached;

        const blocks = await this.db.getLatestBlocks(limit);
        
        await this.cache.set(cacheKey, blocks, 5); // Cache 5 seconds
        return blocks;
    }

    async getTransaction(txId: string): Promise<any> {
        const cacheKey = `tx:${txId}`;
        
        const cached = await this.cache.get(cacheKey);
        if (cached) return cached;

        const response = await this.restClient.get(`/transactions/${txId}`);
        const data = response.data;
        
        await this.cache.set(cacheKey, data, 3600);
        return data;
    }

    async getAddressInfo(address: string): Promise<any> {
        const cacheKey = `address:${address}`;
        
        const cached = await this.cache.get(cacheKey);
        if (cached) return cached;

        // Get from database
        const balance = await this.db.getAddressBalance(address);
        
        if (balance) {
            await this.cache.set(cacheKey, balance, 30); // Cache 30 seconds
            return balance;
        }

        // Fallback to REST
        const response = await this.restClient.get(`/addresses/${address}`);
        const data = response.data;
        
        await this.cache.set(cacheKey, data, 30);
        return data;
    }

    // Real-time block monitoring optimized for 10 BPS
    startBlockMonitoring(callback: (block: any) => void): void {
        if (this.isMonitoring) return;
        
        this.isMonitoring = true;
        logger.info('Starting block monitoring (10 BPS mode)');

        // Poll every 100ms (10 blocks per second = 100ms per block)
        this.monitoringInterval = setInterval(async () => {
            try {
                const networkInfo = await this.getNetworkInfo();
                const currentBlueScore = networkInfo.virtualDaaScore || 0;

                if (currentBlueScore > this.lastProcessedBlueScore) {
                    const blocksToFetch = currentBlueScore - this.lastProcessedBlueScore;
                    
                    // Fetch new blocks (with limit to prevent overload)
                    const limit = Math.min(blocksToFetch, 50);
                    const blocks = await this.getLatestBlocks(limit);
                    
                    // Process each new block
                    for (const block of blocks) {
                        if (block.blue_score > this.lastProcessedBlueScore) {
                            callback(block);
                        }
                    }
                    
                    this.lastProcessedBlueScore = currentBlueScore;
                }
            } catch (error) {
                logger.error('Block monitoring error:', error);
            }
        }, config.blockPollInterval);
    }

    stopBlockMonitoring(): void {
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
            this.monitoringInterval = null;
        }
        this.isMonitoring = false;
        logger.info('Stopped block monitoring');
    }
}
